package pbo_m10_5210411401;

public class Mahasiswa {
    private String Nama, NIM, Semester, Prodi;
    private int angkatan, SKS;
    
    public Mahasiswa() {
        
    }

    public Mahasiswa(String Nama, String NIM, String Semester, String Prodi, int angkatan, int SKS) {
        this.Nama = Nama;
        this.NIM = NIM;
        this.Semester = Semester;
        this.Prodi = Prodi;
        this.angkatan = angkatan;
        this.SKS = SKS;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    }

    public void setNIM(String NIM) {
        this.NIM = NIM;
    }

    public void setSemester(String Semester) {
        this.Semester = Semester;
    }

    public void setProdi(String Prodi) {
        this.Prodi = Prodi;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }

    public void setSKS(int SKS) {
        this.SKS = SKS;
    }

    public String getNama() {
        return Nama;
    }

    public String getNIM() {
        return NIM;
    }

    public String getSemester() {
        return Semester;
    }

    public String getProdi() {
        return Prodi;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public int getSKS() {
        return SKS;
    }
    
    public String CetakInfoMahasiswa() {
        StringBuilder sb = new StringBuilder();
        sb.append("INFO MAHASISWA");
        sb.append("\nNama :\t " + getNama());
        sb.append("\nNIM :\t " + getNIM());
        sb.append("\nAngkatan :\t " + getAngkatan());
        sb.append("\nSemester :\t " + getSemester());
        sb.append("\nProdi :\t " + getProdi());
        sb.append("\nSKS :\t " + getSKS());
        sb.append("\n \n \t");
        sb.append(cetakTagihanSPP());
        
        
        return sb.toString();
    }
    
    public String hitungSPPTetap() {
        StringBuilder sppt = new StringBuilder();
        if (getProdi() == "Teknik Informatika") {
            if (getAngkatan() == 2021) {
                int SPPTetap = 2250000;
                sppt.append(SPPTetap);
            } else if (getAngkatan() == 2020) {
                int SPPTetap = 2150000;
                sppt.append(SPPTetap);
            } else if (getAngkatan() <= 2019) {
                int SPPTetap = 2050000;
                sppt.append(SPPTetap);
            }
        }else if (getProdi() == "Teknik Industri") {
            if (getAngkatan() == 2021) {
                int SPPTetap = 1750000;
                sppt.append(SPPTetap);
            } else if (getAngkatan() == 2020) {
                int SPPTetap = 1700000;
                sppt.append(SPPTetap);
            } else if (getAngkatan() <= 2019) {
                int SPPTetap = 1650000;
                sppt.append(SPPTetap);
            }
            
        }
        
        return sppt.toString();
    }
    
    public String hitungSPPVariabel() {
       StringBuilder sppv = new StringBuilder();
        if (getProdi() == "Teknik Informatika") {
            if (getAngkatan() == 2021) {
                int SPPVar = 250000 * this.SKS;
                sppv.append(SPPVar);
            } else if (getAngkatan() == 2020) {
                int SPPVar = 245000 * this.SKS;
                sppv.append(SPPVar);
            } else if (getAngkatan() <= 2019) {
                int SPPVar = 240000 * this.SKS;
                sppv.append(SPPVar);
            }
    
        }else if (getProdi() == "Teknik Industri") {
            if (getAngkatan() == 2021) {
                int SPPVar = 190000 * this.SKS;
                sppv.append(SPPVar);
            } else if (getAngkatan() == 2020) {
                int SPPVar = 180000 * this.SKS;
                sppv.append(SPPVar);
            } else if (getAngkatan() <= 2019) {
                int SPPVar = 170000 * this.SKS;
                sppv.append(SPPVar);
            }
                   
        }
        
        
        return sppv.toString();
    }
    
    public String hitungTotalSPP() {
        StringBuilder tspp = new StringBuilder();
        int TotalSPP;
        int STP = Integer.parseInt(hitungSPPTetap());
        int STV = Integer.parseInt(hitungSPPVariabel());
        TotalSPP = STP + STV;
        tspp.append(TotalSPP);
        return tspp.toString();
    }
    
    public String cetakTagihanSPP() {
        StringBuilder spp = new StringBuilder();
        spp.append("DATA TAGIHAN MAHASISWA");
        spp.append("\nSPP TETAP : RP. " + hitungSPPTetap());
        spp.append("\nSPP VARIABEL : RP. " + hitungSPPVariabel());
        spp.append("\nTotal Tagihan SPP Semester ini : RP. " + hitungTotalSPP());

        return spp.toString();
        
    }
}
