package pbo_m13_5210411401;

public class NimHarus10Digit extends Exception{
    @Override
    public String getMessage() {
        return "NIM yang diinputkan harus 10 digit";
    }
    
}
