package pbo_m13_5210411401;

public class NimHarusPositifException extends Exception {
    
    @Override
    public String getMessage() {
        return "Inputan NIM Harus Positif";
    }
    
}
